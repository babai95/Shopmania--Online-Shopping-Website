<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="style1.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
       
   
      <table width="100%" style="height:900px">
    <tr>
        <td valign="top" style="background-image: url('images/backg.jpg');">
            <h1 style="color: black;text-align: center">PRODUCTS</h1>
            
            <a align="center" id='menu' href='electronics1.php'>Electronics</a><br><br><br>
            
           
            <a id='menu' href='clothes1.php'>Clothes</a><br><br><br>
            <a id='menu' href='books1.php'>Books</a><br><br><br>
           
        </td>
    </tr>
    
</table>
    </body>
</html>