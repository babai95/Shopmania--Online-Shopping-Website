<table width='100%'>
    <tr>
        <td>
             <table width='100%' height='200px'>
                <tr>
                    <td> 
                        <a id='menu' href='register.php'>Registration</a>
                    </td>
                    </tr>
                        <tr>
                    <td>  
                         <a id='menu' href='product.php?id=2'>laptops</a>
                    </td>
                    </tr>
                    <tr>
                    <td> 
                         <a id='menu' href='cloth.html'>Clothes</a>
                    </td>
                    </tr>
                    <tr>
                    <td> 
                         <a id='menu' href='product.php?id=1'>watches</a>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>  