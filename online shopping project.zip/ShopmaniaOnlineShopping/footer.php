<style>
    .footer{
    position:fixed;
    left:0;
    bottom:0;
    background-color: yellow;
    width:100%;
        text-align:center;
}
</style>
<div class="footer">
 &copy reserved by hpes 
</div>

