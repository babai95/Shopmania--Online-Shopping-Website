<html>
<head>
<link rel="stylesheet" href="menu.css">
</head>
<body>
<ul class="ul1">

<li class="li1"><a href="#">Home</a></li>
<li class="li2"><a href="#">Logout</a></li>
</ul>
</body>
</html>
