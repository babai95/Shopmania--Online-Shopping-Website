<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="style1.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
       
   
      <table width="100%" style="height:900px">
    <tr>
        <td valign="top" style="background-image: url('images/backg.jpg');">
            <h1 style="color: black;text-align: center">ELECTRONICS</h1>
            
            <a align="center" id='menu' href='product1.php?id=1'>laptops</a><br><br><br>
            
           
            <a id='menu' href='product1.php?id=2'>mobiles</a><br><br><br>
            <a id='menu' href='product1.php?id=3'>watches</a><br><br><br>
           
        </td>
    </tr>
    
</table>
    </body>
</html>