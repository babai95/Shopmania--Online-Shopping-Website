<?php
session_start();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title> Online Shopping India - Shop Online for Branded laptops, Clothing & Accessories in India -Shopmania  </title>
	       
    </head>
    <body style="background-image: url('images/bg1.jpg')">
        <table width="100%">
            <tr>
                <td>
                    <table width="100%" >
                        <tr style="height:100px">
                            <td>
                                <?php include('./header.php')?>
                            </td>
                            
                            
                        </tr>
                        
                    </table>
                    <br>
                    <br>
                    <br>
                    <table width="100%" border="1">
                        <tr>
                            <td>
                                <?php include('./right.php')?>
                            </td>
                            <td valign='top'>
                                <script type="text/javascript">
                                    document.write("home page");
                                    alert("best shop");
                                  </script>  
                                <br>
                                THIS IS SHOPMANIA, THE BEST ONLINE SHOPPING WEBSITE
                                <br>
                                and my first website
                                         
                            </td>
                        </tr>
                    </table>
                                
                                
                            
                            
                            
                            
                            
                   
                    <table width="100%">
                        <tr>
                            <td>
                                <?php include('./footer.php')?>
                            </td>
                            
                            
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
       
        
        
    </body>
</html>
